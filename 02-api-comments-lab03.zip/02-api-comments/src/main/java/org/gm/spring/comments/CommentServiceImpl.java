package org.gm.spring.comments;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


public class CommentServiceImpl implements CommentService {
    private List<Comment> comments = new ArrayList<>();

    public void addComment(Comment comment) {
        comments.add(comment);
    }

    public List<Comment> getAllComments() {
        return comments;
    }


    public List<Comment> getCommentsByEmail(String email) {
        return comments.stream().filter(element -> element.getEmail().equals(email)).collect(Collectors.toList());
    }
}
