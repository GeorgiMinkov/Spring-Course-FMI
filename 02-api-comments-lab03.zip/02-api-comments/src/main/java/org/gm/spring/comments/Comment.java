package org.gm.spring.comments;

import lombok.*;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
@Component
@PropertySource(value = "classpath:comments.properties", ignoreResourceNotFound = true)
@PropertySource(value = "classpath:emails.properties", ignoreResourceNotFound = true)
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@Data
//@NoArgsConstructor
//@RequiredArgsConstructor
//@AllArgsConstructor
@Builder
public class Comment {
    private String text;

    @NonNull
    private String email;

    private LocalDateTime dateTime = LocalDateTime.now();
}
