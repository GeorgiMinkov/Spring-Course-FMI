package org.gm.spring.comments;

public class CommentsConsoleLoggerImpl implements CommentLoggerService {
}
