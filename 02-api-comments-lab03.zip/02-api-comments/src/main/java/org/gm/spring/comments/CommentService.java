package org.gm.spring.comments;

import java.util.List;

public interface CommentService {
    void addComment(Comment comment);
    List<Comment> getAllComments();
    List<Comment> getCommentsByEmail(String email);
}
