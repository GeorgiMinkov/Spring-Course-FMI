package org.gm.spring.comments;

import org.iproduct.spring.comments.CommentsService;

public interface CommentLoggerService {
    public void dumpAlldumpAllComments();
    public void dumpCommentsByAuthor(String authorEmail);
    public CommentsService getCommentsService();
    public void setCommentsService(CommentsService supplier);
}
