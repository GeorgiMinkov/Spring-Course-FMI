package org.gminkov.spring.webflux.webfluxintro.service;

import org.gminkov.spring.webflux.webfluxintro.dao.ArticleRepository;
import org.gminkov.spring.webflux.webfluxintro.model.Article;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

import java.util.Arrays;
import java.util.List;

@Service
public class ArticleServiceImpl implements ArticleService{
//    private static final List<Article> articles = Arrays.asList(new Article[]{
//            new Article("1111111111111111", "New in Spring", "WebFlux is here ..."),
//            new Article("2222222222222222", "New in Spring", "WebFlux is here ..."),
//            new Article("3333333333333333", "New in Spring", "WebFlux is here ...")
//
//    });
//    private static final List<Article> articles = Arrays.asList(new Article[]{
//            new Article("11111111", "New in Spring", "WebFlux")
//});

    @Autowired
    private ArticleRepository repo;

    @Override
    public Flux<Article> getArticles() {
        return repo.findAll();
    }
}
